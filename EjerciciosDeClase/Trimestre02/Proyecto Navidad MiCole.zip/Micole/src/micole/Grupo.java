
package micole;

/**
 *
 * @author Rut
 */

public class Grupo {
    
}
