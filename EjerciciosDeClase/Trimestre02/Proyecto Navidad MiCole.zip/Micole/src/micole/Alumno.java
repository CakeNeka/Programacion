
package micole;


public class Alumno {
    
    // int idAlumno;
    String nombre;
    
    // (Avanzado) LocalDate fechaNac;
    int edad;
    
    // (Todos: comprobación del dni)
    String dni;
    
    // (Avanzado) Este campo sea un enum
    String nombreGrupo;
    
    // (Avanzado) Un array notas bidimensional, con cada una de los módulos
    // y cada uno de los trimestres.
    
    // Array de las notas medias
    double medias;
    
    
    
}
